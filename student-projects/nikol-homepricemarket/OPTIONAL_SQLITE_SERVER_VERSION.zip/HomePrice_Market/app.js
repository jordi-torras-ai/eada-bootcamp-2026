/* HomePrice Market | Ames home value estimator
   The model learns property differences from recorded Ames Housing sales.
   Every displayed valuation is adjusted to the latest bundled Ames FHFA HPI quarter.
*/
(() => {
  'use strict';

  const bundle = window.HOMEPRICE_MODEL;
  const market = bundle.market;
  const marketFactor = market.multiplier;
  const $ = (id) => document.getElementById(id);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const dollars = (value) => new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD', maximumFractionDigits: 0
  }).format(value);
  const integer = (value) => new Intl.NumberFormat('en-US', {maximumFractionDigits: 0}).format(value);
  const neighborhoodLabels = {
    Blmngtn: 'Bloomington Heights', Blueste: 'Bluestem', BrDale: 'Briardale', BrkSide: 'Brookside',
    ClearCr: 'Clear Creek', CollgCr: 'College Creek', Crawfor: 'Crawford', Edwards: 'Edwards',
    Gilbert: 'Gilbert', IDOTRR: 'Iowa DOT / Railroad', MeadowV: 'Meadow Village', Mitchel: 'Mitchell',
    NAmes: 'North Ames', NPkVill: 'Northpark Villa', NWAmes: 'Northwest Ames',
    NoRidge: 'Northridge', NridgHt: 'Northridge Heights', OldTown: 'Old Town',
    SWISU: 'SWISU', Sawyer: 'Sawyer', SawyerW: 'Sawyer West', Somerst: 'Somerset',
    StoneBr: 'Stone Brook', Timber: 'Timberland', Veenker: 'Veenker'
  };
  const qualities = {
    2: ['Needs work', 'Significant repairs and basic finishes.'],
    4: ['Basic', 'Simple materials and standard older finishes.'],
    6: ['Good', 'Comfortable finishes and solid overall construction quality.'],
    8: ['Very good', 'High-quality materials, design and workmanship.'],
    10: ['Excellent', 'Exceptional, top-tier materials and finishes.']
  };
  const typeNames = { '1Fam': 'Detached home', 'TwnhsE': 'Townhouse', 'Twnhs': 'Townhouse',
    Duplex: 'Duplex', '2fmCon': 'Two-family conversion' };
  const defaults = {
    Neighborhood: 'CollgCr', BldgType: '1Fam', GrLivArea: 1700,
    BedroomAbvGr: 3, FullBath: 2, HalfBath: 1, OverallQual: 6,
    YearBuilt: 2000, GarageCars: 2, TotalBsmtSF: '',
    LotArea: '', CentralAir: 'Y', Fireplaces: 0
  };
  let homeType = defaults.BldgType;
  let quality = defaults.OverallQual;
  let connection = false;
  let stats = null;
  let activeMode = 'bundle';
  let lastResult = null;
  let animating = 0;

  function setError(message) { $('form-error').textContent = message || ''; }
  function updateMetrics() {
    const metrics = stats?.metrics || bundle.metrics;
    $('rmse').textContent = dollars(metrics.rmse);
    $('mae').textContent = dollars(metrics.mae);
    $('r2').textContent = Number(metrics.r2).toFixed(3);
    $('n').textContent = integer(metrics.n);
  }

  function renderStatus(mode, message) {
    activeMode = mode;
    const trained = mode === 'trained';
    $('model-indicator').classList.add('ready');
    $('model-indicator').innerHTML = '<span></span> Model ready';
    $('estimation-mark').textContent = 'READY TO ESTIMATE';
    $('estimation-mark').classList.add('ready');
    $('model-status').textContent = message || (trained
      ? 'Gradient boosting fitted on your Ames CSV.'
      : 'Ames-trained ridge model ready — no upload required.');
    $('upload-title').textContent = trained ? 'Switch to another Ames dataset' : 'Want to train a new model?';
    $('upload-copy').innerHTML = trained
      ? 'Drop a replacement <b>train.csv</b> or browse files'
      : 'Optional: drop <b>train.csv</b> to fit gradient boosting';
    $('estimate').disabled = false;
    $('estimate-label').textContent = 'Estimate market value';
    updateMetrics();
    renderAreaInsight();
  }

  function setupNeighborhoods(names) {
    const oldSelection = $('Neighborhood').value || defaults.Neighborhood;
    const list = [...names];
    $('Neighborhood').replaceChildren(...list.map(code => {
      const option = document.createElement('option');
      option.value = code;
      option.textContent = neighborhoodLabels[code] || code;
      return option;
    }));
    $('Neighborhood').value = list.includes(oldSelection) ? oldSelection : list.includes(defaults.Neighborhood) ? defaults.Neighborhood : list[0];
    refreshQuickTags();
    updateSnapshot();
  }

  function refreshQuickTags() {
    const selected = $('Neighborhood').value;
    $$('#quick-neighborhoods [data-neighborhood]').forEach(button => {
      button.classList.toggle('active', button.dataset.neighborhood === selected);
      button.setAttribute('aria-pressed', String(button.dataset.neighborhood === selected));
    });
  }

  function renderAreaInsight() {
    const label = neighborhoodLabels[$('Neighborhood').value] || $('Neighborhood').value;
    $('area-insight-title').textContent = `${label} · Ames, Iowa`;
    $('area-insight-copy').textContent = 'A recognised neighbourhood in the Ames training data. Exact boundaries are not included.';
  }

  function updateSlider() {
    const area = Number($('GrLivArea').value) || defaults.GrLivArea;
    const slider = $('area-slider');
    slider.value = String(Math.min(Number(slider.max), Math.max(Number(slider.min), area)));
    const fraction = (Number(slider.value) - Number(slider.min)) / (Number(slider.max) - Number(slider.min));
    slider.style.setProperty('--slider-percent', `${(fraction * 100).toFixed(2)}%`);
    $('sqm-convert').textContent = `≈ ${integer(Math.round(area * 0.092903))} m²`;
  }

  function updateSnapshot() {
    const code = $('Neighborhood').value;
    $('snapshot-neighborhood').textContent = neighborhoodLabels[code] || code || 'Ames';
    $('snapshot-type').textContent = typeNames[homeType] || homeType;
    $('snapshot-size').textContent = `${integer(Number($('GrLivArea').value) || 0)} sq ft`;
    $('snapshot-beds').textContent = `${$('BedroomAbvGr').value || 0} beds`;
    $('snapshot-quality').textContent = qualities[quality][0];
    const age = 2026 - Number($('YearBuilt').value);
    $('age-display').textContent = Number.isFinite(age) && age >= 0 && age <= 226
      ? `${age} years old` : 'Enter valid year';
    updateSlider();
    renderAreaInsight();
    refreshQuickTags();
  }

  function readInput() {
    const value = id => {
      const text = $(id).value.trim();
      return text === '' ? undefined : Number(text);
    };
    const info = {
      Neighborhood: $('Neighborhood').value,
      BldgType: homeType,
      GrLivArea: value('GrLivArea'),
      BedroomAbvGr: value('BedroomAbvGr'),
      FullBath: value('FullBath'), HalfBath: value('HalfBath'),
      OverallQual: quality,
      YearBuilt: value('YearBuilt'), GarageCars: value('GarageCars'),
      TotalBsmtSF: value('TotalBsmtSF'), LotArea: value('LotArea'),
      Fireplaces: value('Fireplaces'), CentralAir: $('CentralAir').value
    };
    const rules = {
      GrLivArea: [200, 10000, 'Living area'], BedroomAbvGr: [0, 15, 'Bedrooms'],
      FullBath: [0, 10, 'Full bathrooms'], HalfBath: [0, 10, 'Half bathrooms'],
      YearBuilt: [1800, 2026, 'Year built'], GarageCars: [0, 6, 'Garage spaces'],
      TotalBsmtSF: [0, 6000, 'Basement area'], LotArea: [500, 250000, 'Lot size'],
      Fireplaces: [0, 5, 'Fireplaces']
    };
    for (const [key, [min, max, label]] of Object.entries(rules)) {
      const n = info[key];
      if (n === undefined && key !== 'TotalBsmtSF' && key !== 'LotArea') {
        throw new Error(`Please enter ${label.toLowerCase()}.`);
      }
      if (n !== undefined && (!Number.isFinite(n) || n < min || n > max)) {
        throw new Error(`${label} must be between ${integer(min)} and ${integer(max)}.`);
      }
    }
    if (!info.Neighborhood) throw new Error('Please select a neighbourhood.');
    return info;
  }

  function localPrediction(input) {
    const numbers = [
      'GrLivArea', 'BedroomAbvGr', 'FullBath', 'HalfBath', 'OverallQual',
      'YearBuilt', 'GarageCars', 'TotalBsmtSF', 'LotArea', 'Fireplaces'
    ];
    const v = numbers.map(key => input[key] === undefined ? bundle.medians[key] : input[key]);
    const a = v[0], q = v[4], y = v[5];
    v.push(Math.log(Math.max(200, a)), (a / 1500) * (q / 6), ((y - 1900) / 100) * (q / 6));
    for (const cat of ['Neighborhood', 'BldgType', 'CentralAir']) {
      for (const label of bundle.categories[cat].slice(1)) v.push(input[cat] === label ? 1 : 0);
    }
    if (v.length !== bundle.means.length) throw new Error('Model data is not valid.');
    let logPrice = bundle.coefs[0];
    v.forEach((number, i) => { logPrice += bundle.coefs[i + 1] * ((number - bundle.means[i]) / bundle.stds[i]); });
    const baselinePrice = Math.max(10000, Math.exp(logPrice) * bundle.smear);
    const price = Math.round(baselinePrice * marketFactor / 100) * 100;
    const mae = bundle.metrics.mae * marketFactor;
    return {
      price, price_per_sqft: Math.round(price / a),
      illustrative_low: Math.round(Math.max(0, price - 1.5 * mae) / 100) * 100,
      illustrative_high: Math.round((price + 1.5 * mae) / 100) * 100,
      metrics: bundle.metrics, method: 'Ridge regression', market_period: market.latest_period, market_multiplier: marketFactor
    };
  }

  async function serverPrediction(payload) {
    const response = await fetch('/api/predict', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Unable to predict price.');
    return result;
  }

  function showResult(result) {
    lastResult = result;
    const oldValue = Number($('price').dataset.value) || 0;
    const toValue = result.price;
    cancelAnimationFrame(animating);
    const start = performance.now();
    const duration = 740;
    function frame(time) {
      const t = Math.min(1, (time - start) / duration);
      const eased = 1 - (1 - t) ** 4;
      $('price').textContent = dollars(Math.round(oldValue + (toValue - oldValue) * eased));
      if (t < 1) animating = requestAnimationFrame(frame);
      else $('price').dataset.value = String(toValue);
    }
    animating = requestAnimationFrame(frame);
    $('valuation-card').classList.add('has-result');
    $('valuation-heading').textContent = 'Your market-adjusted home estimate.';
    $('estimation-mark').classList.remove('refresh');
    $('estimation-mark').textContent = 'ESTIMATE READY';
    $('ppsf').textContent = `${dollars(result.price_per_sqft)} per sq ft · ${result.market_period || market.latest_period} market index`;
    $('low').textContent = dollars(result.illustrative_low);
    $('high').textContent = dollars(result.illustrative_high);
    $('range-marker').style.left = '50%';
    $('result-status').textContent = `Market-adjusted using Ames FHFA index · ${result.market_period || market.latest_period}`;
    $('snapshot-message').textContent = 'Your inputs are reflected in this estimate. Adjust them to explore another scenario.';
    $('estimate-label').textContent = 'Update market value';
    if (window.innerWidth < 980) {
      $('valuation-card').scrollIntoView({behavior: 'smooth', block: 'center'});
    }
  }

  function markEstimateOld() {
    if (lastResult) {
      $('estimation-mark').textContent = 'INPUTS CHANGED';
      $('estimation-mark').classList.add('refresh');
      $('result-status').textContent = 'Update your estimate to reflect these details';
    }
  }

  async function estimate(event) {
    event?.preventDefault();
    setError('');
    let input;
    try { input = readInput(); }
    catch (error) { setError(error.message); return; }
    const button = $('estimate');
    button.disabled = true;
    $('estimate-label').textContent = 'Calculating your price…';
    try {
      let result;
      if (connection) {
        try { result = await serverPrediction(input); }
        catch (err) {
          if (activeMode === 'trained') throw err;
          result = localPrediction(input);
        }
      } else {
        result = localPrediction(input);
      }
      showResult(result);
    } catch (error) {
      setError(error.message || 'Could not estimate a price.');
      $('estimate-label').textContent = 'Try again';
    } finally { button.disabled = false; }
  }

  function resetForm() {
    HTMLFormElement.prototype.reset.call($('property-form')); // A button named 'reset' shadows form.reset.
    homeType = defaults.BldgType;
    quality = defaults.OverallQual;
    $$('.type-card').forEach(btn => {
      const selected = btn.dataset.type === homeType;
      btn.classList.toggle('selected', selected);
      btn.setAttribute('aria-pressed', String(selected));
    });
    $$('.quality-option').forEach(btn => {
      const selected = Number(btn.dataset.quality) === quality;
      btn.classList.toggle('selected', selected);
      btn.setAttribute('aria-pressed', String(selected));
    });
    ['TotalBsmtSF', 'LotArea'].forEach(id => $(id).value = '');
    $('Neighborhood').value = defaults.Neighborhood;
    $('quality-caption').textContent = 'Good quality';
    $('quality-detail').textContent = qualities[quality][1];
    updateSnapshot();
    lastResult = null;
    cancelAnimationFrame(animating);
    $('price').textContent = '$—';
    $('price').dataset.value = '0';
    $('valuation-heading').textContent = 'A clearer picture of what your home could be worth.';
    $('ppsf').textContent = 'Personalise the details, then request your market estimate.';
    $('low').textContent = '—';
    $('high').textContent = '—';
    $('range-marker').style.left = '0%';
    $('valuation-card').classList.remove('has-result');
    $('estimation-mark').textContent = 'READY TO ESTIMATE';
    $('estimation-mark').classList.remove('refresh');
    $('result-status').textContent = 'Model ready for your next estimate';
    $('estimate-label').textContent = 'Estimate market value';
    $('snapshot-message').textContent = 'Edit the details to personalize your result.';
    setError('');
  }

  function installControls() {
    $('property-form').addEventListener('submit', estimate);
    $('reset').addEventListener('click', resetForm);
    $$('.type-card').forEach(button => button.addEventListener('click', () => {
      homeType = button.dataset.type;
      $$('.type-card').forEach(btn => {
        const selected = btn === button;
        btn.classList.toggle('selected', selected);
        btn.setAttribute('aria-pressed', String(selected));
      });
      updateSnapshot(); markEstimateOld();
    }));
    $$('.quality-option').forEach(button => button.addEventListener('click', () => {
      quality = Number(button.dataset.quality);
      $$('.quality-option').forEach(btn => {
        const selected = btn === button;
        btn.classList.toggle('selected', selected);
        btn.setAttribute('aria-pressed', String(selected));
      });
      $('quality-caption').textContent = `${qualities[quality][0]} quality`;
      $('quality-detail').textContent = qualities[quality][1];
      updateSnapshot(); markEstimateOld();
    }));
    $$('#quick-neighborhoods [data-neighborhood]').forEach(button => button.addEventListener('click', () => {
      if (![...$('Neighborhood').options].some(o => o.value === button.dataset.neighborhood)) return;
      $('Neighborhood').value = button.dataset.neighborhood;
      updateSnapshot(); markEstimateOld();
    }));
    $$('.stepper button[data-step]').forEach(button => button.addEventListener('click', () => {
      const input = $(button.dataset.step);
      const min = Number(input.min), max = Number(input.max);
      const value = Number(input.value) || 0;
      input.value = String(Math.min(max, Math.max(min, value + Number(button.dataset.delta))));
      updateSnapshot(); markEstimateOld();
    }));
    $('area-slider').addEventListener('input', event => {
      $('GrLivArea').value = event.target.value;
      updateSnapshot(); markEstimateOld();
    });
    $$('#property-form input, #property-form select').forEach(input => {
      if (input.id === 'area-slider') return;
      input.addEventListener('input', () => { updateSnapshot(); markEstimateOld(); setError(''); });
      input.addEventListener('change', () => { updateSnapshot(); markEstimateOld(); });
    });
    const modal = $('map-modal');
    const closeMap = () => { modal.hidden = true; document.body.classList.remove('modal-open'); $('open-map').focus(); };
    $('open-map').addEventListener('click', () => {
      if (!$('ames-map').src) $('ames-map').src = 'https://www.openstreetmap.org/export/embed.html?bbox=-93.695%2C41.974%2C-93.565%2C42.091&layer=mapnik&marker=42.0308%2C-93.6319';
      modal.hidden = false;
      document.body.classList.add('modal-open');
      $('close-map').focus();
    });
    $('close-map').addEventListener('click', closeMap);
    modal.addEventListener('click', e => { if (e.target === modal) closeMap(); });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && !modal.hidden) closeMap();
    });
    installUpload();
  }

  function installUpload() {
    const zone = $('upload-zone');
    const input = $('upload');
    zone.addEventListener('click', () => input.click());
    zone.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); }
    });
    zone.addEventListener('dragover', e => { e.preventDefault(); zone.classList.add('dragover'); });
    zone.addEventListener('dragleave', e => { if (!zone.contains(e.relatedTarget)) zone.classList.remove('dragover'); });
    zone.addEventListener('drop', e => {
      e.preventDefault(); zone.classList.remove('dragover');
      const file = e.dataTransfer?.files?.[0];
      if (file) uploadFile(file);
    });
    input.addEventListener('change', () => {
      if (input.files?.[0]) uploadFile(input.files[0]);
      input.value = '';
    });
  }

  async function uploadFile(file) {
    if (!/\.csv$/i.test(file.name)) return $('model-status').textContent = 'Please select a CSV file.';
    if (file.size > 12_000_000) return $('model-status').textContent = 'Maximum file size is 12 MB.';
    if (!connection) {
      $('model-status').textContent = 'To upload and train a custom model, run python app.py and open http://127.0.0.1:5000. The bundled model already works here.';
      return;
    }
    $('upload-progress').hidden = false;
    $('upload-zone').classList.add('uploading');
    $('model-status').textContent = 'Validating and fitting your Ames CSV…';
    try {
      const response = await fetch('/api/upload', {
        method: 'POST', headers: {'Content-Type': 'text/csv'}, body: file
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Upload failed.');
      stats = data.stats;
      setupNeighborhoods(stats.neighborhoods);
      renderStatus(data.mode, data.message);
      lastResult = null;
      $('estimation-mark').textContent = 'READY TO ESTIMATE';
      $('ppsf').textContent = 'Market-adjusted prediction is ready. Enter your details.';
      $('model-status').textContent = `Success — fitted on ${integer(stats.metrics.n)} records. Test RMSE ${dollars(stats.metrics.rmse)}.`;
    } catch (error) { $('model-status').textContent = `Could not train: ${error.message}`; }
    finally { $('upload-progress').hidden = true; $('upload-zone').classList.remove('uploading'); }
  }

  async function init() {
    if (!bundle || !Array.isArray(bundle.coefs)) {
      $('model-status').textContent = 'Bundled model missing. Check model_data.js.';
      setError('Prediction model unavailable.');
      return;
    }
    stats = {metrics: bundle.metrics, neighborhoods: bundle.categories.Neighborhood, medians: bundle.medians};
    setupNeighborhoods(stats.neighborhoods);
    installControls();
    renderStatus('bundle', 'Ames-trained model ready. Uploading a dataset is optional.');
    $('ppsf').textContent = 'Enter the details and discover your estimate.';
    $('result-status').textContent = 'Model ready to estimate';
    if (location.protocol === 'file:') {
      $('model-status').textContent = 'Ready to use offline — built-in model trained on 1,460 Ames sales. Run python app.py for optional CSV retraining.';
      return;
    }
    try {
      const response = await fetch('/api/status', {cache: 'no-store', signal: AbortSignal.timeout(3500)});
      if (!response.ok) throw new Error('Unavailable');
      const state = await response.json();
      if (state.ready) {
        connection = true;
        stats = state.stats;
        setupNeighborhoods(stats.neighborhoods);
        renderStatus(state.mode, state.message);
      }
    } catch {
      $('model-status').textContent = 'Built-in Ames model works in this browser. Start the Python server to enable training on a new CSV.';
    }
  }
  document.addEventListener('DOMContentLoaded', init);
})();

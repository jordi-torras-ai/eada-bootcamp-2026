"""SQLite storage for HomePrice Market. No third-party dependencies.

User records, listings, and conversations are in one database file.
Passwords are salted PBKDF2 hashes; sessions are random HttpOnly cookies, with
only SHA-256 hashes of the session tokens stored at rest.
"""
from __future__ import annotations

import hashlib
import hmac
import math
import os
import re
import secrets
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).with_name('homeprice.sqlite3')
SESSION_LIFETIME = 60 * 60 * 24 * 14
ROUNDS = 260_000
NEIGHBORHOODS = [
 'Blmngtn','Blueste','BrDale','BrkSide','ClearCr','CollgCr','Crawfor','Edwards',
 'Gilbert','IDOTRR','MeadowV','Mitchel','NAmes','NPkVill','NWAmes','NoRidge',
 'NridgHt','OldTown','SWISU','Sawyer','SawyerW','Somerst','StoneBr','Timber','Veenker'
]
TYPES = ['1Fam','Twnhs','TwnhsE','Duplex','2fmCon']

@contextmanager
def connection():
    db = sqlite3.connect(DB_PATH, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=10000')
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def initialize():
    with connection() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript('''
          CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY, email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            password_hash TEXT NOT NULL, salt TEXT NOT NULL,
            display_name TEXT NOT NULL, created_at INTEGER NOT NULL
          );
          CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL
          );
          CREATE TABLE IF NOT EXISTS listings (
            id INTEGER PRIMARY KEY, seller_id INTEGER NOT NULL REFERENCES users(id),
            title TEXT NOT NULL, description TEXT NOT NULL, asking_price INTEGER NOT NULL,
            neighborhood TEXT NOT NULL, home_type TEXT NOT NULL,
            area_sqft INTEGER NOT NULL, beds INTEGER NOT NULL, baths REAL NOT NULL,
            year_built INTEGER NOT NULL, quality INTEGER NOT NULL, garage INTEGER NOT NULL,
            street_text TEXT NOT NULL DEFAULT '', photo_url TEXT NOT NULL DEFAULT '',
            contact_name TEXT NOT NULL, contact_phone TEXT NOT NULL DEFAULT '',
            show_phone INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'active',
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
          );
          CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL REFERENCES listings(id),
            sender_id INTEGER NOT NULL REFERENCES users(id),
            recipient_id INTEGER NOT NULL REFERENCES users(id),
            body TEXT NOT NULL, created_at INTEGER NOT NULL, read_at INTEGER
          );
          CREATE INDEX IF NOT EXISTS idx_listings_status_created ON listings(status, created_at DESC);
          CREATE INDEX IF NOT EXISTS idx_listings_seller ON listings(seller_id);
          CREATE INDEX IF NOT EXISTS idx_msg_sender ON messages(sender_id, created_at);
          CREATE INDEX IF NOT EXISTS idx_msg_recipient ON messages(recipient_id, created_at);
          CREATE INDEX IF NOT EXISTS idx_msg_listing ON messages(listing_id, created_at);
        ''')
        db.execute('DELETE FROM sessions WHERE expires_at < ?', (int(time.time()),))


def public_user(row):
    return dict(id=row['id'], display_name=row['display_name']) if row else None


def account_user(row):
    return {**public_user(row), 'email': row['email']} if row else None


def pbkdf(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                               bytes.fromhex(salt), ROUNDS).hex()


def normalize_email(raw):
    # Intentionally no ownership or delivery verification. Only basic input constraints.
    email = str(raw or '').strip().lower()
    if len(email) > 254 or len(email) < 3 or '@' not in email or any(c.isspace() for c in email):
        raise ValueError('Enter an email address (no verification is required).')
    return email


def password_ok(password):
    if not isinstance(password, str) or not 8 <= len(password) <= 256:
        raise ValueError('Use a password with at least 8 characters.')


def register(obj):
    email = normalize_email(obj.get('email'))
    password = obj.get('password')
    password_ok(password)
    name = str(obj.get('display_name') or '').strip()
    if not 2 <= len(name) <= 60:
        raise ValueError('Enter a name between 2 and 60 characters.')
    salt = secrets.token_hex(16)
    try:
        with connection() as db:
            cur = db.execute('INSERT INTO users(email,password_hash,salt,display_name,created_at) VALUES(?,?,?,?,?)',
                             (email, pbkdf(password, salt), salt, name, int(time.time())))
            uid = cur.lastrowid
    except sqlite3.IntegrityError:
        raise ValueError('An account already uses that email. Sign in instead.') from None
    return create_session(uid)


def login(obj):
    email = normalize_email(obj.get('email'))
    password = obj.get('password')
    if not isinstance(password, str):
        raise ValueError('Incorrect email or password.')
    with connection() as db:
        user = db.execute('SELECT * FROM users WHERE email=?', (email,)).fetchone()
    if not user or not hmac.compare_digest(pbkdf(password, user['salt']), user['password_hash']):
        raise ValueError('Incorrect email or password.')
    return create_session(user['id'])


def create_session(uid):
    token = secrets.token_urlsafe(40)
    with connection() as db:
        db.execute('INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(), uid,
                    int(time.time()) + SESSION_LIFETIME, int(time.time())))
        user = db.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
    return account_user(user), token


def session_user(token):
    if not token:
        return None
    with connection() as db:
        return account_user(db.execute('''SELECT u.* FROM sessions s JOIN users u ON s.user_id=u.id
            WHERE s.token_hash=? AND s.expires_at > ?''',
            (hashlib.sha256(token.encode()).hexdigest(), int(time.time()))).fetchone())


def logout(token):
    if token:
        with connection() as db:
            db.execute('DELETE FROM sessions WHERE token_hash=?',
                       (hashlib.sha256(token.encode()).hexdigest(),))


def text_field(obj, key, max_len, minimum=0):
    s = str(obj.get(key) or '').strip()
    if not minimum <= len(s) <= max_len:
        raise ValueError(f'{key.replace("_", " ").capitalize()} must be {minimum}–{max_len} characters.')
    return s


def int_field(obj, key, low, high):
    try:
        value = float(obj.get(key))
        if not math.isfinite(value) or value != int(value):
            raise ValueError()
        value = int(value)
    except (TypeError, ValueError, OverflowError):
        raise ValueError(f'Invalid value for {key}.') from None
    if not low <= value <= high:
        raise ValueError(f'{key} must be between {low} and {high}.')
    return value


def validate_listing(obj):
    d = {
      'title': text_field(obj, 'title', 100, 8),
      'description': text_field(obj, 'description', 3000, 20),
      'asking_price': int_field(obj, 'asking_price', 10000, 50000000),
      'neighborhood': text_field(obj, 'neighborhood', 20, 1),
      'home_type': text_field(obj, 'home_type', 12, 1),
      'area_sqft': int_field(obj, 'area_sqft', 200, 10000),
      'beds': int_field(obj, 'beds', 0, 15),
      'year_built': int_field(obj, 'year_built', 1800, 2026),
      'quality': int_field(obj, 'quality', 1, 10),
      'garage': int_field(obj, 'garage', 0, 8),
      'street_text': text_field(obj, 'street_text', 150),
      'photo_url': text_field(obj, 'photo_url', 1024),
      'contact_name': text_field(obj, 'contact_name', 80, 2),
      'contact_phone': text_field(obj, 'contact_phone', 50),
      'show_phone': int(bool(obj.get('show_phone'))),
    }
    try:
        d['baths'] = float(obj.get('baths'))
        if not math.isfinite(d['baths']) or not 0 <= d['baths'] <= 12 or d['baths'] * 2 != int(d['baths'] * 2):
            raise ValueError()
    except (TypeError, ValueError):
        raise ValueError('Bathrooms must be between 0 and 12, in half steps.') from None
    if d['neighborhood'] not in NEIGHBORHOODS or d['home_type'] not in TYPES:
        raise ValueError('Please select an Ames neighbourhood and property type.')
    if d['photo_url'] and not re.match(r'^https://[^\s]+$', d['photo_url'], re.I):
        raise ValueError('Property photo must be a valid https:// URL.')
    if d['contact_phone'] and not re.match(r'^[+()0-9 .\-]{5,50}$', d['contact_phone']):
        raise ValueError('Please use a valid contact phone or leave it empty.')
    return d


LISTING_COLS = '''l.id,l.seller_id,l.title,l.description,l.asking_price,l.neighborhood,
 l.home_type,l.area_sqft,l.beds,l.baths,l.year_built,l.quality,l.garage,
 l.street_text,l.photo_url,l.contact_name,l.contact_phone,l.show_phone,l.status,
 l.created_at,l.updated_at,u.display_name AS seller_name'''


def public_listing(row, viewer_id=None):
    d = dict(row)
    if not d.get('show_phone') and viewer_id != d['seller_id']:
        d['contact_phone'] = ''
    d['own_listing'] = (viewer_id == d['seller_id'])
    return d


def get_listing(listing_id, viewer_id=None):
    with connection() as db:
        r = db.execute('SELECT ' + LISTING_COLS + ''' FROM listings l JOIN users u ON l.seller_id=u.id
                         WHERE l.id=?''', (listing_id,)).fetchone()
    if not r or (r['status'] != 'active' and viewer_id != r['seller_id']):
        return None
    return public_listing(r, viewer_id)


def browse(filters, viewer_id=None):
    conditions = ["l.status='active'"]
    args = []
    neighborhood = filters.get('neighborhood', '')
    if neighborhood and neighborhood in NEIGHBORHOODS:
        conditions.append('l.neighborhood=?'); args.append(neighborhood)
    q = str(filters.get('q', '')).strip()[:100]
    if q:
        conditions.append('(l.title LIKE ? OR l.description LIKE ? OR l.street_text LIKE ?)')
        args += [f'%{q}%', f'%{q}%', f'%{q}%']
    try:
        max_price = int(filters.get('max_price', 0))
    except (ValueError, TypeError):
        max_price = 0
    if max_price > 0:
        conditions.append('l.asking_price<=?'); args.append(max_price)
    sorts = {'newest':'l.created_at DESC', 'price_low':'l.asking_price ASC',
             'price_high':'l.asking_price DESC', 'size':'l.area_sqft DESC'}
    order = sorts.get(filters.get('sort'), 'l.created_at DESC')
    sql = 'SELECT ' + LISTING_COLS + ' FROM listings l JOIN users u ON u.id=l.seller_id WHERE ' + ' AND '.join(conditions) + ' ORDER BY ' + order + ' LIMIT 100'
    with connection() as db:
        return [public_listing(r, viewer_id) for r in db.execute(sql, args)]


def mine(uid):
    with connection() as db:
        return [public_listing(r, uid) for r in db.execute('SELECT ' + LISTING_COLS +
               ' FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.seller_id=? ORDER BY l.created_at DESC', (uid,))]


def create_listing(uid, obj):
    item = validate_listing(obj)
    now = int(time.time())
    columns = ['seller_id', *item.keys(), 'status', 'created_at', 'updated_at']
    with connection() as db:
        cur = db.execute('INSERT INTO listings(' + ','.join(columns) + ') VALUES(' + ','.join('?'*len(columns)) + ')',
                  [uid, *item.values(), 'active', now, now])
        listing_id = cur.lastrowid
    return get_listing(listing_id, uid)


def edit_listing(uid, listing_id, obj):
    with connection() as db:
        row = db.execute('SELECT * FROM listings WHERE id=? AND seller_id=?', (listing_id, uid)).fetchone()
        if not row:
            raise PermissionError('Only the seller can edit this listing.')
        combined = {**dict(row), **obj}
        fields = validate_listing(combined)
        status = str(combined.get('status', 'active'))
        if status not in ('active', 'sold'):
            raise ValueError('Listing status must be active or sold.')
        fields['status'] = status
        fields['updated_at'] = int(time.time())
        db.execute('UPDATE listings SET ' + ','.join(f'{k}=?' for k in fields) + ' WHERE id=?',
                   [*fields.values(), listing_id])
    return get_listing(listing_id, uid)


def send_message(uid, obj):
    listing_id = int_field(obj, 'listing_id', 1, 999999999)
    recipient = int_field(obj, 'recipient_id', 1, 999999999)
    body = text_field(obj, 'body', 2000, 2)
    if uid == recipient:
        raise ValueError('You cannot message yourself.')
    with connection() as db:
        l = db.execute('SELECT seller_id,status FROM listings WHERE id=?', (listing_id,)).fetchone()
        if not l:
            raise ValueError('Property not found.')
        if uid != l['seller_id']:
            if l['status'] != 'active' or recipient != l['seller_id']:
                raise PermissionError('Buyers can contact only the seller of an active listing.')
        else:
            prior = db.execute('''SELECT id FROM messages WHERE listing_id=? AND sender_id=?
                                  AND recipient_id=? LIMIT 1''', (listing_id, recipient, uid)).fetchone()
            if not prior:
                raise PermissionError('The buyer must contact you before you can reply.')
        cur = db.execute('INSERT INTO messages(listing_id,sender_id,recipient_id,body,created_at) VALUES(?,?,?,?,?)',
                         (listing_id, uid, recipient, body, int(time.time())))
        return {'id':cur.lastrowid, 'sent': True}


def inbox(uid):
    with connection() as db:
        # A conversation is identified by listing and the other participant.
        rows = db.execute('''
          SELECT m.*, l.title AS listing_title, l.photo_url,
            CASE WHEN m.sender_id=? THEN m.recipient_id ELSE m.sender_id END AS other_id,
            u.display_name AS other_name,
            (SELECT COUNT(*) FROM messages unread WHERE unread.listing_id=m.listing_id
              AND unread.recipient_id=? AND unread.sender_id=(CASE WHEN m.sender_id=? THEN m.recipient_id ELSE m.sender_id END)
              AND unread.read_at IS NULL) AS unread
          FROM messages m
          JOIN listings l ON l.id=m.listing_id
          JOIN users u ON u.id=(CASE WHEN m.sender_id=? THEN m.recipient_id ELSE m.sender_id END)
          WHERE (m.sender_id=? OR m.recipient_id=?)
            AND m.id=(SELECT MAX(x.id) FROM messages x WHERE x.listing_id=m.listing_id
              AND ((x.sender_id=? AND x.recipient_id=(CASE WHEN m.sender_id=? THEN m.recipient_id ELSE m.sender_id END))
                OR (x.recipient_id=? AND x.sender_id=(CASE WHEN m.sender_id=? THEN m.recipient_id ELSE m.sender_id END))))
          ORDER BY m.created_at DESC, m.id DESC LIMIT 100''',
          (uid,uid,uid,uid,uid,uid,uid,uid,uid,uid)).fetchall()
    return [dict(id=r['id'], listing_id=r['listing_id'], listing_title=r['listing_title'],
                 photo_url=r['photo_url'], other_id=r['other_id'], other_name=r['other_name'],
                 snippet=r['body'][:150], unread=r['unread'], time=r['created_at']) for r in rows]


def thread(uid, listing_id, other):
    with connection() as db:
        msgs = db.execute('''SELECT m.id,m.sender_id,m.recipient_id,m.body,m.created_at
         FROM messages m WHERE m.listing_id=? AND
          ((m.sender_id=? AND m.recipient_id=?) OR (m.sender_id=? AND m.recipient_id=?))
          ORDER BY m.id ASC LIMIT 250''', (listing_id, uid, other, other, uid)).fetchall()
        if msgs:
            db.execute('''UPDATE messages SET read_at=? WHERE listing_id=? AND recipient_id=?
                          AND sender_id=? AND read_at IS NULL''', (int(time.time()), listing_id, uid, other))
    return [dict(r) for r in msgs]

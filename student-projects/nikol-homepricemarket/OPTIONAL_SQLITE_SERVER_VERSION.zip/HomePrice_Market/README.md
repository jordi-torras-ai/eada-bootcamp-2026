# HomePrice Market — Ames, Iowa

A polished home valuation and community property marketplace, with a simple SQLite database for accounts, listings and messages.

## Run locally

**Python 3.10 or later. No database installation required.**

1. Extract the ZIP into a folder.
2. Open a terminal in that folder.
3. Run `python app.py` (or `python3 app.py` on macOS).
4. Open **http://127.0.0.1:5000/** for the **Price Estimator (main feature)**.
5. Choose **Browse homes** to visit the marketplace, or open **http://127.0.0.1:5000/market.html**. The marketplace has a prominent **Estimate Price** button to return to the calculator.

SQLite data is created at `homeprice.sqlite3`. Users, listings and messages persist across server restarts. To clear your local demo data, stop the server and remove `homeprice.sqlite3` and any `homeprice.sqlite3-wal` / `homeprice.sqlite3-shm` companion files. The app ships with **no made-up listings or user accounts**.

## Marketplace features

- Register using display name, email and password, or sign in as an existing user.
- Registering **does not verify email ownership** (intentionally simplified for this prototype).
- Create and publish an Ames property listing with a title, description, asking price, neighbourhood, property type, measurements, and contact name; optional public phone and HTTPS property photo URL.
- Browse and filter listings by search, neighbourhood and maximum asking price; sort by newest, lowest/highest price or area.
- View listing details. Buyers must register or sign in before privately messaging a seller.
- Sellers can reply in the same inbox, edit listings and mark a listing sold or relist it.
- Accounts are saved in SQLite; passwords are salted PBKDF2-HMAC-SHA256 hashes, not stored in plaintext. Cookies are `HttpOnly` and `SameSite=Lax`.

## Ames valuation

The home-price estimator continues to use a bundled Ames-trained model with an FHFA index adjustment through **Q2 2026**. The interface displays a single **estimated market-adjusted value**, not a historical estimate or historical-versus-current comparison. The model uses 2006–2010 sale data and a metro-level house-price index: these estimates are illustrative, **not professional appraisals and not validated against recent comparable local sales**.

The estimator works as a static file (`index.html`) using its bundled model, but the marketplace **requires** `python app.py` for accounts, listing database and messages.

To optionally retrain the estimator with the full Ames Kaggle `train.csv`, install the optional packages: `pip install -r requirements.txt`; place `train.csv` beside `app.py`; restart the server. The bundled model works without them.

## Architecture

- `market.html`, `market.css`, `market.js` — premium marketplace, account and messaging interface.
- `index.html`, `styles.css`, `premium.css`, `app.js`, `model_data.js` — market-adjusted price estimator.
- `app.py` — Python standard-library HTTP server, valuation API and authenticated marketplace routes.
- `market_db.py` — SQLite schema, session, user, listing and message operations.
- `model_bundle.json` — embedded Ames estimator coefficients and market index.

## Prototype limitations

- Only for a trusted local demo. Before public deployment, add HTTPS and reverse-proxy configuration, email verification, password recovery, abuse and spam protection, rate limiting, image uploads with content checks, moderation and a stronger account-security review.
- Emails are format-checked minimally but are **not verified**, as requested. Anyone can enter an email address they do not control.
- Photo URLs are remote links supplied by sellers and may become unavailable. Users should not expose sensitive contact information unless they want it visible to strangers.
- Listing data is seller-supplied and not fact-checked. All amounts are in US dollars.
- This app has no payment or transaction handling.

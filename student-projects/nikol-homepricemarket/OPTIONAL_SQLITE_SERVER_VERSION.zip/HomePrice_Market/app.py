"""HomePrice Market — Ames valuation and SQLite-powered listing marketplace.

Run: python app.py
Works with Python's standard library and bundled Ames-trained ridge model.
Optionally add train.csv to train a Histogram Gradient Boosting model (requires
pandas, numpy and scikit-learn). See README.md for provenance and limitations.
"""
from __future__ import annotations

import csv
import io
import json
import math
import os
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Lock
from urllib.parse import urlsplit, parse_qs
from http.cookies import SimpleCookie
import re
import market_db as shop

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'train.csv'
BUNDLE = json.loads((ROOT / 'model_bundle.json').read_text(encoding='utf-8'))
MARKET = BUNDLE['market']
NUMS = ['GrLivArea', 'BedroomAbvGr', 'FullBath', 'HalfBath', 'OverallQual', 'YearBuilt',
        'GarageCars', 'TotalBsmtSF', 'LotArea', 'Fireplaces']
CATS = ['Neighborhood', 'BldgType', 'CentralAir']
FIELDS = CATS + NUMS
MAX_UPLOAD = 12_000_000
MARKET_INDEX = MARKET['latest_index']
HPI = {int(yr): values for yr, values in MARKET['quarterly_index'].items()}
TRAIN_LOCK = Lock()
MODEL = None
STATS = None
TRAIN_ERROR = None


def use_num(obj, key):
    value = obj.get(key)
    if value is None or value == '':
        return float(BUNDLE['medians'][key])
    try:
        n = float(value)
        if not math.isfinite(n):
            raise ValueError()
        return n
    except (ValueError, TypeError):
        raise ValueError(f'Please enter a valid number for {key}.') from None


def validate_input(obj, cats=None):
    if not isinstance(obj, dict):
        raise ValueError('Invalid property details.')
    record = {key: use_num(obj, key) for key in NUMS}
    for key in CATS:
        record[key] = str(obj.get(key) or ('CollgCr' if key == 'Neighborhood' else '1Fam' if key == 'BldgType' else 'Y'))
    if record['Neighborhood'] not in (cats or BUNDLE['categories'])['Neighborhood']:
        raise ValueError('Please select a neighbourhood from the Ames dataset.')
    if record['BldgType'] not in BUNDLE['categories']['BldgType']:
        raise ValueError('Please select a supported building type.')
    if record['CentralAir'] not in ('Y', 'N'):
        raise ValueError('Please choose yes or no for air conditioning.')
    rules = {
        'GrLivArea': (200, 10000), 'BedroomAbvGr': (0, 15), 'FullBath': (0, 10),
        'HalfBath': (0, 10), 'OverallQual': (1, 10), 'YearBuilt': (1800, 2026),
        'GarageCars': (0, 6), 'TotalBsmtSF': (0, 6000),
        'LotArea': (500, 250000), 'Fireplaces': (0, 5)
    }
    for key, (low, high) in rules.items():
        if not low <= record[key] <= high:
            raise ValueError(f'{key} must be between {low:,} and {high:,}.')
    return record


def ridge_features(record):
    vals = [float(record[k]) for k in NUMS]
    area, quality, year = vals[0], vals[4], vals[5]
    vals += [math.log(max(200, area)), (area / 1500) * (quality / 6),
             ((year - 1900) / 100) * (quality / 6)]
    for cat in CATS:
        vals.extend(1.0 if record[cat] == v else 0.0 for v in BUNDLE['categories'][cat][1:])
    return vals


def ridge_predict(record):
    x = ridge_features(record)
    model = BUNDLE
    log_price = model['coefs'][0] + sum(
        model['coefs'][i + 1] * (xv - model['means'][i]) / model['stds'][i]
        for i, xv in enumerate(x))
    return math.exp(log_price) * model['smear']


def stats_payload():
    if MODEL is not None:
        return {'ready': True, 'mode': 'trained', 'stats': STATS,
                'message': f'Gradient boosting fitted. Valuations adjusted to {MARKET["latest_period"]} FHFA index.'}
    return {'ready': True, 'mode': 'bundle',
            'stats': {'metrics': BUNDLE['metrics'], 'neighborhoods': BUNDLE['categories']['Neighborhood'],
                      'medians': BUNDLE['medians'], 'neighborhood_medians': BUNDLE['neighborhood_medians']},
            'message': f'Bundled Ames model ready. Market adjusted to {MARKET["latest_period"]}.',
            'training_error': TRAIN_ERROR}


def predict(obj):
    record = validate_input(obj, STATS['categories'] if STATS else None)
    if MODEL is not None:
        import pandas as pd
        predicted = float(MODEL.predict(pd.DataFrame([record]))[0])
        mae = STATS['metrics']['mae']
        method = 'Histogram gradient boosting'
    else:
        predicted = ridge_predict(record)
        mae = BUNDLE['metrics']['mae']
        method = 'Ridge regression'
    # Only expose a market-adjusted valuation, never the training-era prediction.
    adjustment = STATS['market_multiplier'] if STATS else MARKET['multiplier']
    price = round(max(10000, predicted) * adjustment / 100) * 100
    adjusted_mae = mae * adjustment
    return {
        'price': price,
        'price_per_sqft': round(price / record['GrLivArea']),
        'illustrative_low': round(max(0, price - 1.5 * adjusted_mae) / 100) * 100,
        'illustrative_high': round((price + 1.5 * adjusted_mae) / 100) * 100,
        'method': method,
        'market_period': MARKET['latest_period'],
        'market_multiplier': adjustment,
        'market_index_series': MARKET['series'],
        'metrics': STATS['metrics'] if STATS else BUNDLE['metrics'],
    }


def fit_dataset(path):
    """Validate and fit entirely before publishing the new model."""
    import numpy as np
    import pandas as pd
    from sklearn.compose import ColumnTransformer
    from sklearn.ensemble import HistGradientBoostingRegressor
    from sklearn.impute import SimpleImputer
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
    from sklearn.model_selection import train_test_split
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder

    df = pd.read_csv(path)
    missing = set(FIELDS + ['SalePrice', 'YrSold', 'MoSold']) - set(df.columns)
    if missing:
        raise ValueError('CSV is missing required Ames columns: ' + ', '.join(sorted(missing)))
    df = df.dropna(subset=['SalePrice'])
    if len(df) < 100:
        raise ValueError('Need at least 100 labelled sales to train the model.')
    # Each new CSV must include enough sale timing to calculate its OWN index
    # baseline; applying the stock 2006–2010 factor blindly would be misleading.
    sale_year = pd.to_numeric(df['YrSold'], errors='coerce')
    sale_month = pd.to_numeric(df['MoSold'], errors='coerce')
    hpi_values = []
    for year, month in zip(sale_year, sale_month):
        if not (np.isfinite(year) and np.isfinite(month) and int(year) in HPI and
                year == int(year) and month == int(month) and 1 <= month <= 12):
            raise ValueError('Market adjustment requires sale years 2006–2010 with valid sale months in YrSold/MoSold.')
        hpi_values.append(HPI[int(year)][(int(month) - 1) // 3])
    avg_market_baseline = float(np.mean(hpi_values))
    adjustment = MARKET_INDEX / avg_market_baseline
    X = df[FIELDS].copy()
    y = pd.to_numeric(df['SalePrice'], errors='coerce')
    valid = y.notna() & np.isfinite(y) & (y > 0)
    X, y = X.loc[valid], y.loc[valid]
    for col in NUMS:
        X[col] = pd.to_numeric(X[col], errors='coerce')
    for col in CATS:
        X[col] = X[col].fillna('Unknown').astype(str)
    transformer = ColumnTransformer([
        ('numeric', SimpleImputer(strategy='median'), NUMS),
        ('category', OneHotEncoder(handle_unknown='ignore', sparse_output=False), CATS)
    ])
    def make_pipeline():
        return Pipeline([
            ('preprocess', transformer),
            ('estimator', HistGradientBoostingRegressor(
                max_iter=130, max_leaf_nodes=15, max_depth=5,
                learning_rate=.075, l2_regularization=10, random_state=42))
        ])
    Xt, Xv, yt, yv = train_test_split(X, y, test_size=.2, random_state=42)
    check = make_pipeline()
    check.fit(Xt, yt)
    fitted_preds = check.predict(Xv)
    metrics = {
        'mae': round(float(mean_absolute_error(yv, fitted_preds))),
        'rmse': round(float(np.sqrt(mean_squared_error(yv, fitted_preds)))),
        'r2': round(float(r2_score(yv, fitted_preds)), 3),
        'n': len(X), 'validation': len(yv)
    }
    full = make_pipeline()
    full.fit(X, y)
    stat = {
        'metrics': metrics,
        'market_multiplier': adjustment,
        'market_period': MARKET['latest_period'],
        'neighborhoods': sorted(X['Neighborhood'].dropna().unique().tolist()),
        'categories': {k: sorted(X[k].unique().tolist()) for k in CATS},
        'medians': {k: float(X[k].median()) for k in NUMS},
        'neighborhood_medians': {str(k): round(float(v))
                                 for k, v in df.groupby('Neighborhood').SalePrice.median().items()}
    }
    return full, stat


def install_dataset(data: bytes):
    global MODEL, STATS, TRAIN_ERROR
    if len(data) > MAX_UPLOAD:
        raise ValueError('Dataset is larger than the 12 MB upload limit.')
    try:
        data.decode('utf-8-sig')
    except UnicodeDecodeError:
        raise ValueError('Use a UTF-8 CSV file.') from None
    temp = ROOT / '.train-upload.tmp.csv'
    with TRAIN_LOCK:
        temp.write_bytes(data)
        try:
            model, stats = fit_dataset(temp)
            os.replace(temp, DATA)
            MODEL, STATS, TRAIN_ERROR = model, stats, None
        finally:
            temp.unlink(missing_ok=True)
    return stats_payload()


class Handler(BaseHTTPRequestHandler):
    def respond(self, payload, status=200, cookie=None):
        raw = json.dumps(payload, allow_nan=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        if cookie is not None:
            # localhost uses HTTP; reverse proxies should forward X-Forwarded-Proto=https.
            secure = '; Secure' if self.headers.get('X-Forwarded-Proto') == 'https' else ''
            self.send_header('Set-Cookie', f'hpm_session={cookie}; Path=/; HttpOnly; SameSite=Lax; Max-Age={shop.SESSION_LIFETIME if cookie else 0}{secure}')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def cookie_token(self):
        jar = SimpleCookie()
        try:
            jar.load(self.headers.get('Cookie', ''))
        except Exception:
            return None
        return jar['hpm_session'].value if 'hpm_session' in jar else None

    def current_user(self):
        return shop.session_user(self.cookie_token())

    def require_user(self):
        user = self.current_user()
        if not user:
            raise PermissionError('Please sign in or create an account first.')
        return user

    def request_json(self, limit=128000):
        if 'application/json' not in self.headers.get('Content-Type', '').lower():
            raise ValueError('Send JSON data (Content-Type: application/json).')
        try:
            length = int(self.headers.get('Content-Length', 0))
        except ValueError:
            length = 0
        if length <= 0 or length > limit:
            raise ValueError('Request body is missing or too large.')
        obj = json.loads(self.rfile.read(length))
        if not isinstance(obj, dict):
            raise ValueError('Expected a JSON object.')
        return obj

    def check_origin(self):
        origin = self.headers.get('Origin')
        if origin:
            u = urlsplit(origin)
            if u.netloc.lower() != self.headers.get('Host', '').lower() or u.scheme not in ('http', 'https'):
                raise PermissionError('Request origin is not allowed.')
        # JSON requests + strict Origin check prevent ordinary cross-site forms.

    def do_GET(self):
        from mimetypes import guess_type
        parsed = urlsplit(self.path)
        path = parsed.path
        try:
            user = self.current_user()
            uid = user['id'] if user else None
            if path == '/api/status':
                return self.respond(stats_payload())
            if path == '/api/auth/me':
                return self.respond({'user': user})
            if path == '/api/listings':
                query = {k: v[0] for k, v in parse_qs(parsed.query).items() if v}
                return self.respond({'listings': shop.browse(query, uid)})
            if path == '/api/me/listings':
                return self.respond({'listings': shop.mine(self.require_user()['id'])})
            if path == '/api/inbox':
                return self.respond({'conversations': shop.inbox(self.require_user()['id'])})
            if path == '/api/messages':
                me = self.require_user()
                q = parse_qs(parsed.query)
                listing_id = int(q.get('listing_id', ['0'])[0])
                other = int(q.get('other_user_id', ['0'])[0])
                if listing_id < 1 or other < 1:
                    raise ValueError('Choose a conversation.')
                return self.respond({'messages': shop.thread(me['id'], listing_id, other)})
            match = re.fullmatch(r'/api/listings/(\d+)', path)
            if match:
                listing = shop.get_listing(int(match.group(1)), uid)
                return self.respond({'listing': listing}, 200 if listing else 404)
            if path == '/':
                path = '/index.html'
            if path not in ('/index.html', '/styles.css', '/app.js', '/model_data.js',
                            '/assets/ames-house.svg', '/favicon.svg', '/market.html',
                            '/market.css', '/market.js', '/premium.css'):
                return self.send_error(404)
            resource = ROOT / path.lstrip('/')
            if not resource.is_file():
                return self.send_error(404)
            binary = resource.read_bytes()
            self.send_response(200)
            content_type = guess_type(resource.name)[0] or 'application/octet-stream'
            if content_type.startswith('text/') or content_type in ('application/javascript', 'image/svg+xml'):
                content_type += '; charset=utf-8'
            self.send_header('Content-Type', content_type)
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Length', str(len(binary)))
            self.end_headers()
            self.wfile.write(binary)
        except (ValueError, TypeError) as exc:
            return self.respond({'error': str(exc)}, 400)
        except PermissionError as exc:
            return self.respond({'error': str(exc)}, 401)
        except Exception as exc:
            print('GET API error:', repr(exc))
            return self.respond({'error': 'The request could not be completed.'}, 500)

    def do_POST(self):
        path = urlsplit(self.path).path
        allowed = ('/api/predict','/api/upload','/api/auth/register','/api/auth/login',
                   '/api/auth/logout','/api/listings','/api/messages')
        if path not in allowed:
            return self.send_error(404)
        try:
            self.check_origin()
            if path == '/api/upload':
                # Model uploads are a local development-only operation.
                if self.client_address[0] not in ('127.0.0.1', '::1'):
                    raise PermissionError('Model uploads are restricted to localhost.')
                length = int(self.headers.get('Content-Length', 0))
                if length <= 0:
                    raise ValueError('Empty dataset.')
                if length > MAX_UPLOAD:
                    return self.respond({'error': 'File too large (12 MB maximum).'}, 413)
                return self.respond(install_dataset(self.rfile.read(length)))
            body = {} if path == '/api/auth/logout' else self.request_json()
            if path == '/api/predict':
                return self.respond(predict(body))
            if path == '/api/auth/register':
                user, token = shop.register(body)
                return self.respond({'user': user}, 201, cookie=token)
            if path == '/api/auth/login':
                user, token = shop.login(body)
                return self.respond({'user': user}, cookie=token)
            if path == '/api/auth/logout':
                shop.logout(self.cookie_token())
                return self.respond({'user': None}, cookie='')
            user = self.require_user()
            if path == '/api/listings':
                return self.respond({'listing': shop.create_listing(user['id'], body)}, 201)
            if path == '/api/messages':
                return self.respond(shop.send_message(user['id'], body), 201)
        except PermissionError as exc:
            return self.respond({'error': str(exc)}, 403)
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            return self.respond({'error': str(exc)}, 400)
        except Exception as exc:
            print('POST API error:', repr(exc))
            return self.respond({'error': 'The request could not be completed. Check the server log.'}, 500)

    def do_PATCH(self):
        match = re.fullmatch(r'/api/listings/(\d+)', urlsplit(self.path).path)
        if not match:
            return self.send_error(404)
        try:
            self.check_origin()
            user = self.require_user()
            return self.respond({'listing': shop.edit_listing(user['id'], int(match.group(1)), self.request_json())})
        except PermissionError as exc:
            return self.respond({'error': str(exc)}, 403)
        except (ValueError, TypeError) as exc:
            return self.respond({'error': str(exc)}, 400)
        except Exception as exc:
            print('PATCH API error:', repr(exc))
            return self.respond({'error': 'The request could not be completed.'}, 500)

def main():
    global MODEL, STATS, TRAIN_ERROR
    shop.initialize()
    if DATA.exists():
        try:
            print('Found train.csv; training Histogram Gradient Boosting model...')
            MODEL, STATS = fit_dataset(DATA)
            print('Model RMSE: $%s' % format(STATS['metrics']['rmse'], ','))
        except Exception as exc:
            TRAIN_ERROR = str(exc)
            print('Could not fit train.csv:', TRAIN_ERROR)
            print('Using bundled Ames-trained model instead.')
    else:
        print('Using bundled Ames-trained ridge model. No CSV upload needed.')
    port = int(os.environ.get('PORT', '5000'))
    with ThreadingHTTPServer(('127.0.0.1', port), Handler) as server:
        print('Open http://127.0.0.1:%d/market.html for the marketplace' % port, flush=True)
        print('Open http://127.0.0.1:%d/ for the home price estimator' % port, flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print('\nStopped.')


if __name__ == '__main__':
    main()
